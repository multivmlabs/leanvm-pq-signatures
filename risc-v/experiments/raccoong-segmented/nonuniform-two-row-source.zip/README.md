# Segmented Raccoon-G under RISC-V

The original full Raccoon-G verifier cannot fit one signature under the selected
backend's `2^28` witness cap. This guest keeps the same signature relation and
splits its nine matrix-row equations into **five linked partial proofs**. Parts
check rows `(0,1)`, `(2,3)`, `(4,5)`, `(6,7)` and `(8,8)`. The repeated final row
is executed and charged; it is not an additional signature.

Every part still checks all compact encodings, the complete exact norm, full-key
BUFF binding and the original challenge hash over the complete commitment vector.
It expands its two selected matrix rows through SHAKE inside the VM. Two separated
SDK BLAKE2s hashes bind the complete shared signature and commitment witness.
The final receiver must require all five parts with the same binding for each
authorized key/message pair. One part alone proves only a partial claim.

The [specification](SPEC.md) gives the precise codec, equations, public statement
and composition assumptions. The Raccoon-G profile remains the authors' PoC with
strict decoding and the exact integer norm threshold. Full paper conformance and
parameter-security claims are still pending. The unchanged backend pin is
`06e5c9cd6981103786f9d0a17324241b559a50d3`.

## Identity and first capacity check

The reviewed two-row ELF is
`a9ab1a596f88a737200f96bd045ed4d8176d3f9bcf8eaa6ad06a85ffd9ebfddc`,
28104 bytes. `build-manifest.json` pins 44 source/dependency files and independent
codec controls. The program imports the unchanged original G arithmetic and
norm predicate. It introduces no unchecked arithmetic or hash advice.

For the first original deterministic signature, all five parts execute correctly
and pass the production size check at **226,492,856 witness words** each, with
identical padded table heights. `part-measurements-final-0.json` records those
checks and `.identity.json` binds them to this executable. These are execution
and witness-layout measurements, not proof-production timings or a claim that
the whole signature fits a direct proof. The full corpus must separately satisfy
the native tree's identical-leaf-shape requirement.

The earlier one-row candidate used nine partial leaves and 182,780,344 words per
leaf on the same input. Its exact ELF, source and measurement identities are
preserved in `one-row.elf`, `one-row-source.zip` and `one-row-manifest.json`.

## Preparation and host API

The host crate is `raccoong-segmented-host` in `host/`. Its interface is:

- `ELF`, `ROW_COUNT=9`, `PARTS_PER_SIGNATURE=5`, `ROWS_PER_LEAF=2`;
- `Record` and `PublicRecord`, using the original raw key/message/signature corpus;
- `record(index)` and `records(start,n)`;
- `prepare(&Record) -> PreparedRecord`, freshly reconstructing complete `w` and
  its 64-byte binding;
- `row_run(&PreparedRecord, part)` and
  `expected_row_output(&PublicRecord, part, &binding)`;
- `rows_for_part(part)`, the fixed coverage mapping.

`PreparedRecord` contains `public`, `signature`, packed canonical `w` and
`binding`. No prepared witness or advice is cached. Every fresh pipeline must
include reconstruction of `w`, binding calculation and advice packing in its
prover-work total. Only original key generation and signing are fixture work.
The final receipt carries 64 binding bytes per original signature, in addition
to its root proof. The receiver needs no signature, `w` or child proof files.

## Correctness evidence

Five native/interpreter tests pass on the reviewed ELF. They include 35 actual
ELF executions, with 19 acceptances and 16 rejections:

- Every part of three independent original signatures accepts, and all 6912
  reconstructed commitment coefficients match the authors' Python arithmetic.
- Malformed full keys, messages, challenges, responses, selected hints, commitment
  coefficients and part indices reject. The final commitment coefficient is
  checked even when it is outside the selected rows.
- Python `hashlib.blake2s` independently checks 20 witness hashes and 50 public
  part outputs, including both binding halves and all part/row identifiers.
- Seven challenge-consistent norm controls test the exact threshold, threshold
  plus one, both signs, a larger response and the hint midpoint.
- Changing an unselected row-eight hint can leave part zero valid, but changes
  its binding and makes part four fail. This explicitly demonstrates why full
  receipt verification must enforce common witness binding and complete coverage.

`review/correctness.log` and `review/codec-controls.json` retain the evidence.
These correctness fixtures are excluded from the benchmark corpus and are never
used as free cached witness preparation. Guest/host Clippy passed with warnings
denied. The independent review adds second-row mutation controls; its evidence
is under `risc-v/reviews/raccoon-benchmark/`.

## Reproduction

From the project root:

```sh
.venv/bin/python risc-v/experiments/raccoong-segmented/build_guest.py
CARGO_HOME="$PWD/.cache/riscv-cargo" \
 CARGO_TARGET_DIR="$PWD/.cache/raccoon-fit-target" \
 cargo +stable test --release --locked --offline \
 --manifest-path risc-v/experiments/raccoong-segmented/host/Cargo.toml
```

Proof production and the full public-only receiver are separate runner work.
Report five fresh partial leaves per original signature, every merge and padding
slot, all witness preparation, the complete root plus auxiliary binding bytes,
and full verification. Do not substitute partial-proof counts for signature counts.
