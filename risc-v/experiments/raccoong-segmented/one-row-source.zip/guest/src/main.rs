#![no_std]
#![no_main]
use leanvm_guest::{commit,read};
use raccoong_segmented_guest::{DOMAIN,PK_WORDS,SIG_WORDS,W_WORDS,ROW_COUNT,verify_words};

leanvm_guest::advice_words!(1 << 13);

#[unsafe(no_mangle)]
extern "C" fn main() {
    let row = *read::<u64>();
    assert!(row < ROW_COUNT as u64);
    let pk = read::<[u64;PK_WORDS]>();
    let message = read::<[u64;4]>();
    let signature = read::<[u64;SIG_WORDS]>();
    let w = read::<[u64;W_WORDS]>();
    let digest = verify_words(pk,message,signature,w,row as usize).expect("invalid row claim");
    commit(&DOMAIN);
    commit(&row);
    commit(pk);
    commit(message);
    commit(&digest);
}
